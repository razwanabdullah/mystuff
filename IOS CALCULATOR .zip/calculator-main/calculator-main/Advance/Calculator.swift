//
//  Calculator.swift
//  
//
//  
//

import Foundation
import UIKit


class Calculator : UIViewController{
    
    @IBOutlet weak var textLabel: UILabel!
    
    
    @IBOutlet weak var advanceButton: UIButton!
    @IBOutlet weak var advanceLabel: UILabel!
    var inputList: [String] = []
    var advance = false
    var resultString = ""
    
    // create the alert
            let alert = UIAlertController(title: "Error", message: "Invalid Input", preferredStyle: UIAlertController.Style.alert)

            // add an action (button)
   
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

    }
    
    func calc(){
        var x = 0
        while x<inputList.count{
            if(inputList[x] == "/"){
                let y = Int(inputList[x-1])! /  Int(inputList[x+1])!
                
                inputList[x-1] = String(y)
                
                inputList.remove(at: x)
                
               
                
                inputList.remove(at: x)
                
               
                
            }
            else{
                x = x+1
            }
            
            
            
            print(inputList)
            
        }
        
        x=0
        while x<inputList.count{
            if(inputList[x] == "*"){
                let y = Int(inputList[x-1])! * Int(inputList[x+1])!
                
                inputList[x-1] = String(y)
                
                inputList.remove(at: x)
                
               
                
                inputList.remove(at: x)
                
            
                
            }
            else{
                x = x+1
            }
            
            
            
            print(inputList)
            
        }
        
        x=0
        while x<inputList.count{
            if(inputList[x] == "+"){
                let y = Int(inputList[x-1])! + Int(inputList[x+1])!
                
                inputList[x-1] = String(y)
                
                inputList.remove(at: x)
                
               
                
                inputList.remove(at: x)
                
                
            }
            else{
                x = x+1
            }
            
            
            
            print(inputList)
            
        }
        x=0
        while x<inputList.count{
            if(inputList[x] == "-"){
                let y = Int(inputList[x-1])! - Int(inputList[x+1])!
                
                inputList[x-1] = String(y)
                
                inputList.remove(at: x)
                
               
                
                inputList.remove(at: x)
                
           
                
            }
            else{
                x = x+1
            }
            
            
            
            print(inputList)
            
        }
        

        
        
       
    }
    
    @IBAction func test(_ sender: Any) {
    }
    
    @IBAction func onePress(_ sender: Any) {
        
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0" ){
            textLabel.text  = textLabel.text! + " 1"
            
            inputList.append("1")
        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    @IBAction func onePresses(_ sender: Any) {
        
      
        
    }
    

    
    
    @IBAction func twoPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 2"
            inputList.append("2")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }

    }
    
    
    
    @IBAction func threePress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 3"
            inputList.append("3")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func fourPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 4"
            inputList.append("4")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    
    @IBAction func fivePress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 5"
            inputList.append("5")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    
    @IBAction func sixPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 6"
            inputList.append("6")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func sevenPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 7"
            inputList.append("7")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func eightPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 8"
            inputList.append("8")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func ninePress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 9"
            inputList.append("9")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func zeroPress(_ sender: Any) {
        if(textLabel.text!.last != "1" && textLabel.text!.last != "2" && textLabel.text!.last != "3" && textLabel.text!.last != "4" && textLabel.text!.last != "5" && textLabel.text!.last != "6" && textLabel.text!.last != "7" && textLabel.text!.last != "8" && textLabel.text!.last != "9" && textLabel.text!.last != "0"){
            textLabel.text  = textLabel.text! + " 0"
            inputList.append("0")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    
    
    @IBAction func plusPress(_ sender: Any) {
        if(textLabel.text!.last != "+" && textLabel.text!.last != "-" && textLabel.text!.last != "*" && textLabel.text!.last != "/"){
            textLabel.text  = textLabel.text! + " +"
            inputList.append("+")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    
    @IBAction func minusPress(_ sender: Any) {
        if(textLabel.text!.last != "+" && textLabel.text!.last != "-" && textLabel.text!.last != "*" && textLabel.text!.last != "/"){
            textLabel.text  = textLabel.text! + " -"
            inputList.append("-")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
        
    }
    
    
    @IBAction func multiPress(_ sender: Any) {
        if(textLabel.text!.last != "+" && textLabel.text!.last != "-" && textLabel.text!.last != "*" && textLabel.text!.last != "/"){
            textLabel.text  = textLabel.text! + " *"
            inputList.append("*")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
    }
    
    @IBAction func dividePress(_ sender: Any) {
        if(textLabel.text!.last != "+" && textLabel.text!.last != "-" && textLabel.text!.last != "*" && textLabel.text!.last != "/"){
            textLabel.text  = textLabel.text! + " /"
            inputList.append("/")

        }
        else{
            self.present(alert, animated: true, completion: nil)

        }
        

    }
    
    
    @IBAction func equalPress(_ sender: Any) {
        calc()
        textLabel.text  = textLabel.text! + " = " + inputList[0]
        
        resultString = resultString + textLabel.text! + "\n"
        
        if(advance){
            advanceLabel.text = resultString
        }
       
        
    }
    
    
    @IBAction func advancePress(_ sender: Any) {
        if(!advance){
            advanceButton.setTitle("Simple - Without History", for: .normal)
            advanceLabel.text = resultString
            advance=true
            
        }
        else{
            advanceButton.setTitle("Advance - With History", for: .normal)
            advanceLabel.text = ""
            advance=false
            
        }
        
    }
    @IBAction func clearPress(_ sender: Any) {
        textLabel.text = ""
        inputList = []
    }
}

//
//  DataFile.swift
//  cashApp
//
//  Created by Sarvech Ali on 11/10/2021.
//

import Foundation

class DataFile{
    var name:String
    
    init(name:String){
        self.name = name
    }
}
